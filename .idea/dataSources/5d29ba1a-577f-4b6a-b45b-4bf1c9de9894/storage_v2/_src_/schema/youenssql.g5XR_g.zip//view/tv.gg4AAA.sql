create definer = root@localhost view tv as
select `youenssql`.`emp`.`DEPTNO` AS `deptno`, avg(`youenssql`.`emp`.`SAL`) AS `asal`
from `youenssql`.`emp`
group by `youenssql`.`emp`.`DEPTNO`;

